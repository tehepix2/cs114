package pets;

public interface Trainable {
	public String doTrick(); 
}
