package lab8;

public class Tester {

	/**
	 * Check if str is balanced
	 * Example for balanced strings: "", "{}", "{() []}", "{([()[]])}" etc.
	 * Example for unbalanced strings: "(", "]" , "[)", "{()[]", etc. 
	 * Use a stack
	 */
	public static boolean balancedParentheses(String str) {
		return false; // STUB
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	}

}
