package linkListLab;

public class Tester {

	public static void main(String[] args) {
		VNode<Integer> A = new VNode<Integer>(3); 
		VNode<Integer> B = new VNode<Integer>(7); 
		VNode<Integer> C = new VNode<Integer>(8); 
		VNode<Integer> D = new VNode<Integer>(10); 
		VNode<Integer> E = new VNode<Integer>(4);
		VNode<Integer> F = new VNode<Integer>(2);
		VNode<Integer> G = new VNode<Integer>(7);
		
		A.setNext(B);
		B.setNext(C);
		C.setNext(D);
		D.setNext(E);
		E.setNext(F);
		F.setNext(G);
	}
	
	/** Returns space separated values of the list. 
     *  Example "3 7 8 10 4 2 7" for above list
     **/
	public static <E> String toString(VNode<E> head) {
		return ""; //Stub
	}
	/** 
	 * Returns True if the list starting at head has a cycle, False otherwise
	 */
	public static <E> boolean hasCycle(VNode<E> head) {
		return false; // Stub
	}
}
